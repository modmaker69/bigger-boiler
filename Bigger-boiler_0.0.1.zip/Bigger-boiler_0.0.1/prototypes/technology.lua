local bigger_boiler = {
	type = "technology",
	name = "Bigger boiler",
	icon = "__Bigger-boiler__/graphics/icons/boiler.png",
	icon_size = 50,
	order = "c",
	prerequisizes = {}, 
	effects = {
		{type = "unlock-recipe", recipe="bigger boiler"},
	},
	unit = {
		count = 50,
		ingredients = {
			{"automation-science-pack", 1},
			{"logistic-science-pack", 1},
		},
		time = 20,
	},
}
			

data:extend({bigger_boiler})