local bigger_boiler = {
	type = "recipe",
	name = "bigger boiler",
	ingredients = {
	{"iron-plate", 70},
	{"copper-plate", 50},
	{"steel-plate", 20},
	{"boiler", 1},
	{"stone-brick", 150},
	
	},
	result = "bigger boiler",
	energy_required = 10,

}

data:extend({bigger_boiler})