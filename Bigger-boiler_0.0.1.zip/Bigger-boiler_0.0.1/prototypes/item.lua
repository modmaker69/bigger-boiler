local bigger_boiler = {
	type= "item",
	name = "bigger boiler",
	icon = "__Bigger-boiler__/graphics/icons/boiler.png",
	icon_size = 50,
	subgroup = "other",
	stack_size = 50,
}

data:extend({bigger_boiler})
